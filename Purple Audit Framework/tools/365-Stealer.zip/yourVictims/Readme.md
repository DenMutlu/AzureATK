# 365-Stealer Installation Guide on XAMPP for Windows

This guide provides a step-by-step process for installing XAMPP on Windows and configuring it to run the 365-Stealer project.

## Step 1: Install XAMPP for Windows

1. Download XAMPP for Windows from the [official website](https://www.apachefriends.org/index.html).
2. Run the XAMPP installer and follow the on-screen instructions to complete the installation.

## Step 2: Start Apache and MySQL Services on XAMPP

1. Open the XAMPP control panel from the Start menu.
2. Start the Apache and MySQL services by clicking on the "Start" buttons next to them.

![xampp server](partials/img/xampp.png)

## Step 3: Move the 365-Stealer Project to XAMPP htdocs

1. Copy the 365-Stealer project to the XAMPP `htdocs` directory:
   ```bash
   copy C:\path\to\365-Stealer C:\xampp\htdocs\
   ```

## Step 4: Visit phpMyAdmin Page

1. Open a web browser and go to `http://localhost/phpmyadmin`.
2. Create a new database named `database-1`:
   - Click on the "New" button in the left sidebar.
   - Enter `database-1` in the "Database name" field and click on "Create".
3. Create a table named `login` with 6 columns:
   - Click on the `database-1` database in the left sidebar.
   - Click on the "SQL" tab and run the following SQL command:
     ```sql
     CREATE TABLE login (
         username VARCHAR(30) NOT NULL,
         password VARCHAR(256) NOT NULL,
         is_password_changed TINYINT(1) NOT NULL,
         last_password_change DATE NOT NULL,
         role VARCHAR(10) NOT NULL DEFAULT 'user',
         status VARCHAR(10) NOT NULL DEFAULT 'active'
     );
     ```
     ![](partials/img/Login_Structure.png)
4. Insert values into the `login` table:

   - Click on the `login` table in the left sidebar.
   - Click on the "Insert" tab and enter the following values:
     - username: `admin` (\*Note: Use user name as admin)
     - password: `<Password>` (\*Function = password_hash() PHP function)
     - is_password_changed: `0`
     - last_password_change: `Current Date`
     - role: `admin`
     - status: `active`

   ![](partials/img/column.png)

## Step 5: Implement Brute Force Protection

To prevent brute force attacks, create a failed_logins table and implement logic to block IP addresses after a certain number of failed attempts.

1. Create the failed_logins table by running the following SQL command:

   ```sql
   CREATE TABLE failed_logins (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) NOT NULL,
      ip_address VARCHAR(45) NOT NULL,
      attempt_time DATETIME NOT NULL,
      successful TINYINT(1) DEFAULT 0
   );
   ```

   ![](partials/img/failed_logins.png)

2. Implement the logic to track failed login attempts and block IP addresses after a specified number of attempts in the login script.

## Step 6: Change the Root Password through phpMyAdmin

1. Open phpMyAdmin and log in.

2. Click on the "User accounts" tab.

3. Find the `root` user under "User accounts" and click on "Edit privileges".
   ![](partials/img/rootpassword_setup.png)

4. Scroll down to the "Change password" section and enter the new password.

5. Click on "Go" to save the changes.
   ![](partials/img/rootpassword_setup2.png)

## Step 7: Update the `connection.php` File

1. Open the `connection.php` file in the 365-Stealer project:
   ```bash
   notepad C:\xampp\htdocs\365-Stealer\yourVictims\connection.php
   ```
2. Update the `password` variable with the root password set in Step 5:
   ```php
   $password = 'your_root_password';
   ```

## Step 8: Update the `config.inc.php` File

1. Open the `config.inc.php` file:
   ```bash
   notepad C:\xampp\phpMyAdmin\config.inc.php
   ```
2. Make the following changes:
   ```php
   $cfg['Servers'][$i]['auth_type'] = 'cookie';
   $cfg['Servers'][$i]['password'] = '';
   ```
   ![xampp server](partials/img/config.inc.png)

## Step 9: Restart Apache and MySQL Services

1. Open the XAMPP control panel from the Start menu.
2. Stop and then start the Apache and MySQL services.

Your XAMPP installation and configuration for the 365-Stealer project on Windows is now complete.

---
